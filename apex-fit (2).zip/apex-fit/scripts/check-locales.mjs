import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

const dir = "src/i18n/locales";
const files = readdirSync(dir).filter((f) => f.endsWith(".json"));
const base = JSON.parse(readFileSync(join(dir, "en.json"), "utf8"));

function keys(obj, prefix = "") {
  return Object.entries(obj).flatMap(([k, v]) =>
    typeof v === "object" && v !== null ? keys(v, `${prefix}${k}.`) : [`${prefix}${k}`]
  );
}

const baseKeys = keys(base);
let failed = false;

for (const f of files) {
  const code = f.replace(".json", "");
  if (code === "he" || code === "iw") {
    console.error(`✖ محظورة: ${f}`);
    failed = true;
    continue;
  }
  const data = JSON.parse(readFileSync(join(dir, f), "utf8"));
  const have = new Set(keys(data));
  const missing = baseKeys.filter((k) => !have.has(k));
  if (missing.length) {
    console.error(`✖ ${code}: مفاتيح ناقصة (${missing.length}):`, missing.slice(0, 5));
    failed = true;
  }
}

if (failed) process.exit(1);
console.log(`✔ ${files.length} لغة، كل المفاتيح مكتملة`);
