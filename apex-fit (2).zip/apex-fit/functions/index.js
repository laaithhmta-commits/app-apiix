// Firebase Cloud Function: المدرب الذكي
// المفتاح يُحفظ كسرّ (Secret) في Firebase ولا يُكتب في الكود أبداً.
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");

const ANTHROPIC_API_KEY = defineSecret("ANTHROPIC_API_KEY");
const MODEL = "claude-haiku-5-5";

const SYSTEM_PROMPT = `You are Apex Fit's Smart Coach for men's home fitness and sports nutrition.
Rules:
- Answer in the same language the user writes in.
- Give general training and nutrition guidance only. Never diagnose, never prescribe medication or supplement doses.
- If the user reports pain, injury, or persistent low mood, tell them to stop and consult a doctor or professional.
- Respect the user's limitations listed in the profile (knee, shoulder, lower back, wrist).
- Keep answers short and practical.`;

exports.coachChat = onCall(
  { secrets: [ANTHROPIC_API_KEY], region: "us-central1", maxInstances: 10 },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "سجّلي دخولك أولاً.");
    }

    const { messages, profile } = request.data || {};
    if (!Array.isArray(messages) || messages.length === 0) {
      throw new HttpsError("invalid-argument", "الرسائل غير صالحة.");
    }

    // نأخذ آخر 12 رسالة فقط ونتحقق من شكلها
    const history = messages
      .slice(-12)
      .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));

    const profileText = profile
      ? `Profile: age ${profile.age ?? "?"}, weight ${profile.weight ?? "?"}kg, height ${profile.height ?? "?"}cm, level ${profile.level ?? "?"}, limitations ${profile.limitations ?? "none"}.`
      : "";

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY.value(),
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 600,
        system: `${SYSTEM_PROMPT}\n${profileText}`,
        messages: history,
      }),
    });

    if (!res.ok) {
      throw new HttpsError("internal", "تعذّر الاتصال بالمدرب.");
    }

    const data = await res.json();
    const reply = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .trim();

    return { reply: reply || "..." };
  }
);
