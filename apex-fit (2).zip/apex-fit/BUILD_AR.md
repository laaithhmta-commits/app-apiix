# دليل بناء APK / AAB لتطبيق Apex Fit

## قبل أي شيء: ملف .env

انسخي `.env.example` إلى ملف اسمه `.env`، واملئي المفاتيح الأربعة من إعدادات مشروع Firebase. بدونه يُبنى التطبيق ولكن تسجيل الدخول لن يعمل.

## الطريقة الأسهل: جهاز كمبيوتر + Android Studio

الخطوة تحتاج كمبيوتر (ويندوز أو ماك أو لينكس)، لأن بناء APK يحتاج أدوات Android. من الهاتف وحده ما بتقدري تبنيه.

1. ثبّتي **Node.js** (LTS) من nodejs.org.
2. ثبّتي **Android Studio** من developer.android.com/studio، وافتحيه مرة واحدة ليكمل تنزيل الأدوات تلقائياً.
3. فكّي ملف `apex-fit.zip` في مجلد على الكمبيوتر.
4. افتحي Terminal داخل مجلد المشروع، ونفّذي بالترتيب:

```bash
npm install
npm run build
npx cap sync android
```

5. للحصول على **ملف AAB** (لرفعه على Google Play):

```bash
cd android
./gradlew bundleRelease
```

الملف يكون في: `android/app/build/outputs/bundle/release/app-release.aab`

6. للحصول على **ملف APK** (لتثبيته مباشرة على هاتف Android):

```bash
cd android
./gradlew assembleRelease
```

الملف يكون في: `android/app/build/outputs/apk/release/app-release.apk`

على ويندوز استخدمي `gradlew.bat` بدل `./gradlew`.

### أو من Android Studio بدون أوامر

افتحي مجلد `android` من Android Studio، ثم من القائمة: **Build → Generate Signed App Bundle / APK**، واختاري المفتاح من `android/app/apex-fit.jks`.

## مفتاح التوقيع (مهم جداً)

تم إنشاء المفتاح لكِ داخل المشروع:
- الملف: `android/app/apex-fit.jks`
- كلمة المرور والإعدادات: `android/keystore.properties`

**احتفظي بنسخة من الملفين في مكان آمن** (فلاش أو بريد خاص). إذا ضاع المفتاح، لن تقدري تحدّثين التطبيق على Google Play أبداً، وستحتاجين تطبيقاً جديداً بالكامل.

لا ترفعي هذين الملفين على أي موقع عام.

## رفع التطبيق على Google Play

1. أنشئي حساب مطور في play.google.com/console (رسوم تسجيل لمرة واحدة).
2. اختاري **Create app** واملئي البيانات.
3. ارفعي ملف `app-release.aab` في قسم الإصدار الإنتاجي أو الاختباري.
4. أكملي قسم سياسة الخصوصية وتقييم المحتوى (تحتاج رابط سياسة خصوصية، وهذا التطبيق يجمع بيانات المستخدم ويحتاج إفصاحاً واضحاً).

## أشياء ستحتاجينها قبل النشر

- **صور المتجر والفيديوهات:** المجلدان `public/images` و`public/videos` فيهما صور مؤقتة فقط. الفيديوهات غير موجودة، وتحتاجين تضيفينها بنفس الأسماء المكتوبة في ملفات التمارين.
- **مراجعة المحتوى الطبي:** الحقائق الغذائية والتوصيات الصحية تحتاج مراجعة مختصة قبل النشر.
- **Google Sign-In داخل APK:** يحتاج plugin أصلياً إضافياً، ولا يعمل بالطريقة الحالية داخل التطبيق.
- **المدرب الذكي:** يحتاج دالة سحابية منشورة على Firebase، وإلا سيظهر خطأ اتصال.

## قواعد أمان قاعدة البيانات

الملف `firestore.rules` يحمي بيانات كل مستخدم بحيث لا يقرأها غيره. انسخي محتواه في Firebase Console ← Firestore Database ← Rules ثم اضغطي Publish.

## تفعيل المدرب الذكي (Smart Coach)

1. افتحي console.anthropic.com وأنشئي مفتاح API، واحفظيه في مكان آمن. الاستخدام مدفوع حسب الكمية.
2. في Firebase Console فعّلي خطة **Blaze** (مطلوبة لنشر الدوال).
3. من الكمبيوتر، داخل مجلد المشروع، نفّذي:

```bash
npm install -g firebase-tools
firebase login
cd functions && npm install && cd ..
firebase functions:secrets:set ANTHROPIC_API_KEY
firebase deploy --only functions
```

الدالة `coachChat` موجودة في `functions/index.js`، والمفتاح يُحفظ في Firebase فقط.

## الفيديوهات

أسماء الملفات المطلوبة موجودة في مجلد `public/videos`، مثل `push_standard.mp4` و`legs_bodyweight_squat.mp4`. ضعي فيديو لكل تمرين بنفس الاسم بالضبط (MP4، قصير وخفيف).
