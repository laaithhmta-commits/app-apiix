// الماكروز تقديرية لكل حصة مبنية على قيم USDA، وتختلف حسب الماركة والكمية.
export const ALL_RECIPES = [
  {
    id: "recipe_salmon_quinoa",
    title: { ar: "وعاء السلمون والكينوا", en: "Salmon & Quinoa Bowl" },
    category: "healthy",
    macros: { kcal: 620, proteinG: 41, carbsG: 34, fatG: 36 },
    ingredients: [
      { ar: "سلمون مطبوخ 150 غرام", en: "Cooked salmon 150 g" },
      { ar: "كينوا مطبوخة 120 غرام", en: "Cooked quinoa 120 g" },
      { ar: "نصف حبة أفوكادو", en: "Half avocado" },
      { ar: "سبانخ 60 غرام", en: "Spinach 60 g" },
      { ar: "ملعقة صغيرة زيت زيتون", en: "1 tsp olive oil" },
    ],
    steps: {
      ar: ["اطبخ الكينوا حسب التعليمات.", "اشوِ السلمون حتى ينضج.", "رتّب السبانخ والكينوا والأفوكادو، وأضف السلمون والزيت والليمون."],
      en: ["Cook quinoa per package instructions.", "Grill salmon until cooked.", "Arrange spinach, quinoa and avocado; top with salmon, oil and lemon."],
    },
  },
  {
    id: "recipe_chicken_lentil_bowl",
    title: { ar: "وعاء الدجاج والعدس", en: "Chicken & Lentil Rice Bowl" },
    category: "athlete_post",
    macros: { kcal: 690, proteinG: 66, carbsG: 76, fatG: 13 },
    ingredients: [
      { ar: "صدر دجاج مطبوخ بدون جلد 150 غرام", en: "Cooked skinless chicken breast 150 g" },
      { ar: "عدس مطبوخ 150 غرام", en: "Cooked lentils 150 g" },
      { ar: "أرز بني مطبوخ 150 غرام", en: "Cooked brown rice 150 g" },
      { ar: "خضار مشكلة 100 غرام", en: "Mixed vegetables 100 g" },
    ],
    steps: {
      ar: ["اشوِ الدجاج ثم قطّعه.", "سخّن العدس والأرز.", "اطبخ الخضار بقليل من الزيت ورتّب الكل."],
      en: ["Grill chicken, then slice.", "Warm the lentils and rice.", "Sauté vegetables lightly and assemble the bowl."],
    },
  },
  {
    id: "recipe_oats_banana_yogurt",
    title: { ar: "شوفان الموز والزبادي", en: "Oats, Banana & Yogurt" },
    category: "athlete_pre",
    macros: { kcal: 457, proteinG: 26, carbsG: 80, fatG: 5 },
    ingredients: [
      { ar: "شوفان 60 غرام", en: "Oats 60 g" },
      { ar: "موزة متوسطة 120 غرام", en: "Medium banana 120 g" },
      { ar: "زبادي يوناني قليل الدسم 150 غرام", en: "Low-fat Greek yogurt 150 g" },
      { ar: "عسل 10 غرام", en: "Honey 10 g" },
    ],
    steps: {
      ar: ["اطبخ الشوفان بالماء أو الحليب قليل الدسم.", "أضف الموز والزبادي والعسل."],
      en: ["Cook oats with water or low-fat milk.", "Add banana, yogurt and honey."],
    },
  },
  {
    id: "recipe_athlete_pre_banana_toast",
    title: { ar: "موزة وتوست القمح الكامل مع الفول السوداني", en: "Banana, Whole-Grain Toast & Peanut Butter" },
    category: "athlete_pre",
    macros: { kcal: 350, proteinG: 11, carbsG: 57, fatG: 10 },
    ingredients: [
      { ar: "موزة متوسطة 120 غرام", en: "Medium banana 120 g" },
      { ar: "شريحتان خبز قمح كامل 60 غرام", en: "Two slices whole-wheat bread 60 g" },
      { ar: "زبدة فول سوداني 15 غرام", en: "Peanut butter 15 g" },
    ],
    steps: {
      ar: ["حمّص الخبز قليلاً وادهنه بزبدة الفول السوداني.", "قدّم الموز بجانبه."],
      en: ["Toast bread lightly and spread peanut butter.", "Serve banana on the side."],
    },
  },
  {
    id: "recipe_athlete_post_chicken_rice",
    title: { ar: "دجاج مشوي مع أرز بني وبروكلي", en: "Grilled Chicken, Brown Rice & Broccoli" },
    category: "athlete_post",
    macros: { kcal: 480, proteinG: 54, carbsG: 49, fatG: 7 },
    ingredients: [
      { ar: "صدر دجاج مطبوخ بدون جلد 150 غرام", en: "Cooked skinless chicken breast 150 g" },
      { ar: "أرز بني مطبوخ 180 غرام", en: "Cooked brown rice 180 g" },
      { ar: "بروكلي مطبوخ بالبخار 100 غرام", en: "Steamed broccoli 100 g" },
    ],
    steps: {
      ar: ["اشوِ الدجاج مع الليمون والبهارات دون ملح مضاف.", "اطبخ الأرز والبروكلي بالبخار وقدّمها معاً."],
      en: ["Grill chicken with lemon and salt-free spices.", "Cook rice; steam broccoli and serve together."],
    },
  },
  {
    id: "recipe_athlete_post_yogurt_dates",
    title: { ar: "زبادي يوناني مع تمر وشيا وتوت", en: "Greek Yogurt, Dates, Chia & Berries" },
    category: "athlete_post",
    macros: { kcal: 280, proteinG: 23, carbsG: 37, fatG: 4.5 },
    ingredients: [
      { ar: "زبادي يوناني قليل الدسم 200 غرام", en: "Low-fat Greek yogurt 200 g" },
      { ar: "تمرتان 20 غرام", en: "Two dates 20 g" },
      { ar: "ملعقة كبيرة بذور شيا 12 غرام", en: "1 tbsp chia seeds 12 g" },
      { ar: "توت مشكل 80 غرام", en: "Mixed berries 80 g" },
    ],
    steps: {
      ar: ["ضع الزبادي في وعاء، ثم أضف التمر والتوت.", "رش بذور الشيا فوقه."],
      en: ["Place yogurt in a bowl; add dates and berries.", "Sprinkle chia seeds on top."],
    },
  },
  {
    id: "recipe_athlete_sports_drink",
    title: { ar: "مشروب رياضي منزلي (للتمارين الطويلة)", en: "Homemade Sports Drink (Long Sessions)" },
    category: "athlete_during",
    macros: { kcal: 80, proteinG: 0, carbsG: 21, fatG: 0 },
    ingredients: [
      { ar: "ماء 500 مل", en: "Water 500 ml" },
      { ar: "سكر أو عسل 20 غرام", en: "Sugar or honey 20 g" },
      { ar: "ثُمن ملعقة صغيرة ملح", en: "1/8 tsp salt" },
      { ar: "عصير ليمون ملعقتان كبيرتان", en: "2 tbsp lemon juice" },
    ],
    steps: {
      ar: ["امزج الماء والسكر والملح حتى يذوب، ثم أضف الليمون.", "اشرب بالرشفات أثناء التمرين الطويل فقط."],
      en: ["Mix water, sugar and salt until dissolved; add lemon.", "Sip during long sessions only."],
    },
  },
  {
    id: "recipe_healthy_quinoa_lentil_salad",
    title: { ar: "سلطة الكينوا والعدس والفلفل", en: "Quinoa, Lentil & Pepper Salad" },
    category: "healthy",
    macros: { kcal: 430, proteinG: 17, carbsG: 60, fatG: 14 },
    ingredients: [
      { ar: "كينوا مطبوخة 150 غرام", en: "Cooked quinoa 150 g" },
      { ar: "عدس مطبوخ 100 غرام", en: "Cooked lentils 100 g" },
      { ar: "فلفل ملون 100 غرام", en: "Bell pepper 100 g" },
      { ar: "خيار 80 غرام", en: "Cucumber 80 g" },
      { ar: "ملعقة كبيرة زيت زيتون", en: "1 tbsp olive oil" },
    ],
    steps: {
      ar: ["قطّع الفلفل والخيار واخلطهما مع الكينوا والعدس.", "تبّل بالزيت والليمون والنعناع."],
      en: ["Dice pepper and cucumber; mix with quinoa and lentils.", "Dress with oil, lemon and mint."],
    },
  },
  {
    id: "recipe_healthy_eggs_spinach",
    title: { ar: "فطور البيض بالسبانخ وخبز القمح", en: "Egg & Spinach Breakfast with Whole-Grain Toast" },
    category: "healthy",
    macros: { kcal: 300, proteinG: 19, carbsG: 21, fatG: 16 },
    ingredients: [
      { ar: "بيضتان 100 غرام", en: "Two eggs 100 g" },
      { ar: "سبانخ 80 غرام", en: "Spinach 80 g" },
      { ar: "طماطم 100 غرام", en: "Tomato 100 g" },
      { ar: "شريحة خبز قمح كامل 30 غرام", en: "1 slice whole-wheat bread 30 g" },
    ],
    steps: {
      ar: ["اقلِ السبانخ والطماطم بملعقة زيت، ثم أضف البيض.", "قدّمه مع الخبز."],
      en: ["Sauté spinach and tomato in oil; add eggs.", "Serve with bread."],
    },
  },
  {
    id: "recipe_yogurt_berry_walnut",
    title: { ar: "وعاء الزبادي والتوت والجوز", en: "Greek Yogurt, Berry & Walnut Bowl" },
    category: "general",
    macros: { kcal: 283, proteinG: 23, carbsG: 27, fatG: 11 },
    ingredients: [
      { ar: "زبادي يوناني قليل الدسم 200 غرام", en: "Low-fat Greek yogurt 200 g" },
      { ar: "توت مشكل 80 غرام", en: "Mixed berries 80 g" },
      { ar: "جوز 15 غرام", en: "Walnuts 15 g" },
    ],
    steps: {
      ar: ["ضع الزبادي، ثم أضف التوت والجوز المفروم."],
      en: ["Place yogurt in a bowl; add berries and chopped walnuts."],
    },
  },
  {
    id: "recipe_lentil_spinach_soup",
    title: { ar: "شوربة العدس بالسبانخ", en: "Lentil & Spinach Soup" },
    category: "general",
    macros: { kcal: 332, proteinG: 20, carbsG: 52, fatG: 6 },
    ingredients: [
      { ar: "عدس مطبوخ 150 غرام", en: "Cooked lentils 150 g" },
      { ar: "سبانخ 80 غرام", en: "Spinach 80 g" },
      { ar: "ملعقة صغيرة زيت زيتون", en: "1 tsp olive oil" },
      { ar: "خبز أسمر 40 غرام", en: "Whole-wheat bread 40 g" },
    ],
    steps: {
      ar: ["قلِّ البصل والثوم في الزيت، ثم أضف العدس والماء واطبخ حتى يلين.", "أضف السبانخ في الدقيقة الأخيرة وقدّمها مع الخبز."],
      en: ["Sauté onion and garlic; add lentils and water and simmer.", "Add spinach last minute; serve with bread."],
    },
  },
  {
    id: "recipe_tuna_chickpea_salad",
    title: { ar: "سلطة التونة والحمص", en: "Tuna & Chickpea Salad" },
    category: "general",
    macros: { kcal: 460, proteinG: 37, carbsG: 37, fatG: 17 },
    ingredients: [
      { ar: "تونة معلبة في ماء مصفاة 100 غرام", en: "Tuna in water, drained 100 g" },
      { ar: "حمص مطبوخ 120 غرام", en: "Cooked chickpeas 120 g" },
      { ar: "طماطم وخيار 150 غرام", en: "Tomato and cucumber 150 g" },
      { ar: "ملعقة كبيرة زيت زيتون", en: "1 tbsp olive oil" },
    ],
    steps: {
      ar: ["قطّع الخضار، ثم أضف الحمص والتونة.", "تبّل بالزيت والليمون وقدّم."],
      en: ["Chop vegetables; add chickpeas and tuna.", "Dress with oil and lemon; serve."],
    },
  },
];
