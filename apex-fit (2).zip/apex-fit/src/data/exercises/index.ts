import upperPush from "./upper-push.json";
import upperPull from "./upper-pull.json";
import lowerBody from "./lower-body.json";
import core from "./core.json";

export type Level = "beginner" | "intermediate" | "expert";
export type Prescription = { sets: number; reps: string; workSec: number; restSec: number };

export type Exercise = {
  id: string;
  name: { ar: string; en: string };
  muscles: string[];
  equipment: "bodyweight" | "home_tools";
  type?: "warmup";
  levels: Record<Level, Prescription>;
  steps: { ar: string[]; en: string[] };
  formTips: { ar: string; en?: string };
  video: string;
  image: string;
};

export const GROUPS: { key: string; items: Exercise[] }[] = [
  { key: "push", items: upperPush as Exercise[] },
  { key: "pull", items: upperPull as Exercise[] },
  { key: "legs", items: lowerBody as Exercise[] },
  { key: "core", items: core as Exercise[] },
];

export const EXERCISES: Exercise[] = GROUPS.flatMap((g) => g.items);
