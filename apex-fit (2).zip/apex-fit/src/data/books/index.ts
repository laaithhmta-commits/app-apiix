export type BookChapter = {
  id: string;
  title: { ar: string; en: string };
  pages: { ar: string[]; en: string[] };
};

export type Book = {
  id: string;
  title: { ar: string; en: string };
  chapters: BookChapter[];
};

export const BOOKS: Book[] = [
  {
    id: "book_performance_fuel",
    title: { ar: "وقود الأداء", en: "Performance Fuel" },
    chapters: [
      {
        id: "ch1_protein",
        title: { ar: "البروتين والبناء العضلي", en: "Protein & Muscle Building" },
        pages: {
          ar: [
            "يحتاج المتدرب بالمقاومة عادةً إلى نحو 1.6 إلى 2.2 غرام بروتين لكل كيلوغرام من وزن الجسم يومياً.",
            "وزّع البروتين على 3 إلى 5 وجبات تقريباً، وبكميات تتراوح غالباً بين 20 و40 غرام لكل وجبة.",
            "البروتين قبل النوم، مثل الكازين أو الزبادي اليوناني، قد يدعم التعافي خلال الليل.",
            "المصادر الحيوانية كاملة الأحماض الأمينية، أما النباتية فتحتاج تنوعاً (بقوليات مع حبوب) لتكتمل.",
          ],
          en: [
            "Resistance-trained adults generally benefit from about 1.6 to 2.2 g protein per kg body weight daily.",
            "Spread protein over 3 to 5 meals, typically 20 to 40 g per meal.",
            "Protein before sleep, such as casein or Greek yogurt, may support overnight recovery.",
            "Animal sources are complete; plant sources need variety (legumes with grains) to cover all amino acids.",
          ],
        },
      },
      {
        id: "ch2_carbs_timing",
        title: { ar: "الكربوهيدرات وتوقيت الوجبات", en: "Carbohydrates & Meal Timing" },
        pages: {
          ar: [
            "الكربوهيدرات هي الوقود الأساسي للتمارين عالية الشدة، وتعيد ملء مخزون الجلايكوجين بعد التمرين.",
            "قبل التمرين بساعة إلى ساعتين: وجبة متوازنة تحتوي على كربوهيدرات معقدة وبروتين وكمية قليلة من الدهون.",
            "بعد التمرين بنحو 45 دقيقة إلى ساعتين: بروتين مع كربوهيدرات، خاصة إذا كان التمرين مكثفاً.",
            "أيام الراحة: قلّل الكربوهيدرات قليلاً مع الحفاظ على البروتين والخضار.",
          ],
          en: [
            "Carbohydrates are the primary fuel for high-intensity work and refill muscle glycogen after training.",
            "1 to 2 hours before training: a balanced meal with complex carbs, protein and little fat.",
            "45 minutes to 2 hours after training: protein with carbohydrates, especially after intense sessions.",
            "Rest days: slightly fewer carbs, while keeping protein and vegetables.",
          ],
        },
      },
      {
        id: "ch3_fats_micros",
        title: { ar: "الدهون والمغذيات الدقيقة", en: "Fats & Micronutrients" },
        pages: {
          ar: [
            "الدهون غير المشبعة (زيت الزيتون، الأفوكادو، المكسرات) تدعم الصحة العامة وامتصاص الفيتامينات A وD وE وK.",
            "الأوميغا-3 من الأسماك الدهنية مثل السلمون والسردين مصدر مفيد، والمكملات تحتاج استشارة طبية عند تناول مميعات الدم.",
            "الحديد مهم للطاقة والأداء، والمصادر الحيوانية أعلى امتصاصاً من النباتية، وإضافة فيتامين C تساعد الحديد النباتي.",
            "الكالسيوم وفيتامين D يدعمان صحة العظام، ويُفضّل توزيع الكالسيوم على اليوم.",
          ],
          en: [
            "Unsaturated fats (olive oil, avocado, nuts) support general health and absorption of vitamins A, D, E and K.",
            "Omega-3 from fatty fish like salmon and sardines is beneficial; supplements need medical advice if you take blood thinners.",
            "Iron supports energy and performance; animal sources are absorbed better, and vitamin C helps plant iron.",
            "Calcium and vitamin D support bone health; spread calcium across the day.",
          ],
        },
      },
      {
        id: "ch4_hydration",
        title: { ar: "الترطيب والأداء", en: "Hydration & Performance" },
        pages: {
          ar: [
            "الجفاف المعتدل قد يقلل الأداء والتركيز، لذلك يُنصح بشرب الماء بانتظام طوال اليوم.",
            "في التمارين الطويلة أو العرق الشديد، قد يحتاج الجسم إلى صوديوم وسوائل إضافية.",
            "لون البول الأصفر الفاتح مؤشر عام جيد على الترطيب الكافي.",
          ],
          en: [
            "Mild dehydration can reduce performance and focus; drink water steadily through the day.",
            "For long or very sweaty sessions, the body may need extra sodium and fluids.",
            "Pale yellow urine is a general sign of adequate hydration.",
          ],
        },
      },
      {
        id: "ch5_vitamins_minerals",
        title: { ar: "الفيتامينات والمعادن الأساسية", en: "Essential Vitamins & Minerals" },
        pages: {
          ar: [
            "الغذاء المتنوع يغطي معظم احتياجات الفيتامينات والمعادن لدى الأصحاء، والمكملات تُستخدم عند نقص مثبت أو بتوصية طبية.",
            "فيتامين D يُنتج في الجلد بالتعرض للشمس، ومصادره الغذائية قليلة، لذلك قد يحتاج بعض الأشخاص إلى فحص مستوياته.",
            "فيتامين B12 يوجد أساساً في الأطعمة الحيوانية، والنباتيون الصارمون يحتاجون مصدراً موثوقاً أو مكملاً.",
            "الزنك والمغنيسيوم يدعمان وظائف العضلات والأعصاب، ويُحصل عليهما من اللحوم والبقوليات والمكسرات والحبوب الكاملة.",
          ],
          en: [
            "A varied diet covers most vitamin and mineral needs for healthy adults; supplements are for proven deficiency or medical advice.",
            "Vitamin D is made in the skin with sun exposure and has few food sources, so some people may need testing.",
            "Vitamin B12 is mainly in animal foods; strict vegans need a reliable source or supplement.",
            "Zinc and magnesium support muscle and nerve function and come from meat, legumes, nuts and whole grains.",
          ],
        },
      },
      {
        id: "ch6_beginner_fueling",
        title: { ar: "التغذية للمبتدئين", en: "Fueling for Beginners" },
        pages: {
          ar: [
            "ابدأ بثلاث وجبات رئيسية ووجبة خفيفة واحدة، واجعل كل وجبة فيها بروتين وخضار.",
            "لا تحتاج إلى تعقيد الحسابات في الأسابيع الأولى. الهدف هو الانتظام وشرب الماء والنوم الكافي.",
            "إذا كان هدفك زيادة العضلات، فزد الكمية تدريجياً وراقب وزنك والشعور العام.",
          ],
          en: [
            "Start with three main meals and one snack, with protein and vegetables in each meal.",
            "You do not need complex calculations in the first weeks. Focus on consistency, water and sleep.",
            "If your goal is muscle gain, increase intake gradually and monitor weight and how you feel.",
          ],
        },
      },
      {
        id: "ch7_body_composition",
        title: { ar: "تكوين الجسم وعجز السعرات المعتدل", en: "Body Composition & Moderate Deficit" },
        pages: {
          ar: [
            "لتقليل الدهون مع الحفاظ على العضل، يُفضّل عجز معتدل. الإرشادات الشائعة تشير إلى فقدان نحو 0.5% إلى 1% من وزن الجسم أسبوعياً.",
            "عجز السعرات الكبير لفترات طويلة قد يقلل كتلة العضل والطاقة، لذلك يُنصح بالمتابعة.",
            "البروتين العالي أثناء العجز يساعد على الحفاظ على العضل والشعور بالشبع.",
            "قِس تقدمك بمعدل أسبوعي من الوزن ومحيط الخصر والصور، لا بالوزن اليومي وحده.",
          ],
          en: [
            "For fat loss while preserving muscle, a moderate deficit is preferred; common guidance is about 0.5% to 1% of body weight per week.",
            "A large deficit for long periods can reduce muscle and energy, so it should be monitored.",
            "Higher protein during a deficit helps preserve muscle and supports fullness.",
            "Track progress weekly using average weight, waist circumference and photos, not daily weight alone.",
          ],
        },
      },
    ],
  },
  {
    id: "book_recovery_energy",
    title: { ar: "التعافي وتوازن الطاقة", en: "Recovery & Energy Balance" },
    chapters: [
      {
        id: "ch1_sleep_food",
        title: { ar: "النوم والتغذية", en: "Sleep & Nutrition" },
        pages: {
          ar: [
            "قلة النوم ترفع الشهية وتؤثر على هرمونات الجوع والشبع.",
            "تجنب الكافيين قبل النوم بساعات عدة، لأن تأثيره قد يستمر لفترة طويلة.",
            "وجبة خفيفة تحتوي على بروتين وكربوهيدرات معقدة قبل النوم بساعة قد تساعد بعض الأشخاص.",
          ],
          en: [
            "Poor sleep increases appetite and disrupts hunger and fullness hormones.",
            "Avoid caffeine several hours before bed, as its effect can last a long time.",
            "A light snack with protein and complex carbs an hour before sleep may help some people.",
          ],
        },
      },
      {
        id: "ch2_energy_stability",
        title: { ar: "استقرار الطاقة طوال اليوم", en: "Stable Energy All Day" },
        pages: {
          ar: [
            "الوجبات المتوازنة تساعد على استقرار سكر الدم، وتقلل الهبوط المفاجئ في الطاقة.",
            "الإفراط في السكريات المكررة قد يسبب ارتفاعاً سريعاً ثم انخفاضاً في الطاقة.",
            "إذا استمر التعب الشديد أو تغيرات المزاج لأسابيع، فالأفضل مراجعة طبيب، لأن أسبابه قد تكون طبية.",
          ],
          en: [
            "Balanced meals help stabilize blood sugar and reduce sudden energy drops.",
            "Excess refined sugar can cause a quick spike then a crash.",
            "If severe fatigue or mood changes persist for weeks, see a doctor, as causes may be medical.",
          ],
        },
      },
    ],
  },
  {
    id: "book_mood_kitchen",
    title: { ar: "المطبخ الداعم للمزاج", en: "Mood-Supportive Kitchen" },
    chapters: [
      {
        id: "ch1_gut_brain",
        title: { ar: "الأمعاء والدماغ", en: "Gut & Brain Connection" },
        pages: {
          ar: [
            "هناك اهتمام علمي متزايد بالعلاقة بين الأمعاء والدماغ، لكن معظم الأدلة ما زالت أولية.",
            "الأطعمة الغنية بالألياف والخضار والبقوليات تدعم تنوع البكتيريا النافعة في الأمعاء.",
            "الأطعمة المخمرة مثل الزبادي واللبن قد تضيف تنوعاً، والنتائج تختلف من شخص لآخر.",
          ],
          en: [
            "Scientific interest in the gut-brain connection is growing, but most evidence is still preliminary.",
            "Fiber-rich foods, vegetables and legumes support a diverse gut microbiome.",
            "Fermented foods like yogurt and laban may add diversity; results vary between individuals.",
          ],
        },
      },
      {
        id: "ch2_key_nutrients",
        title: { ar: "المغذيات الداعمة للطاقة والمزاج", en: "Nutrients Supporting Energy & Mood" },
        pages: {
          ar: [
            "أوميغا-3 من الأسماك الدهنية مصدر مفيد ضمن نظام غذائي متوازن.",
            "المغنيسيوم يوجد في المكسرات والبقوليات والخضار الورقية، ونقصه قد يؤثر على الشعور بالتعب.",
            "فيتامين B12 وحمض الفوليك ضروريان لوظائف الأعصاب وإنتاج خلايا الدم، ويوجدان في البيض والبقوليات والخضار الورقية.",
            "الكربوهيدرات المعقدة تمنح طاقة أكثر استقراراً من السكريات المكررة.",
          ],
          en: [
            "Omega-3 from fatty fish is a beneficial part of a balanced diet.",
            "Magnesium is found in nuts, legumes and leafy greens; low intake may contribute to fatigue.",
            "Vitamin B12 and folate are essential for nerve function and blood cell production; found in eggs, legumes and leafy greens.",
            "Complex carbohydrates provide steadier energy than refined sugars.",
          ],
        },
      },
      {
        id: "ch3_limits",
        title: { ar: "ما يجب تقليله", en: "What to Limit" },
        pages: {
          ar: [
            "الكحول يؤثر على النوم وتخليق البروتين العضلي، ويُفضّل تقليله أو تجنبه.",
            "الكافيين مفيد باعتدال، لكن الإفراط أو تناوله المتأخر قد يسبب قلقاً وأرقاً عند بعض الأشخاص.",
            "السكريات المضافة والمشروبات المحلاة تسبب تقلبات سريعة في الطاقة.",
          ],
          en: [
            "Alcohol affects sleep and muscle protein synthesis; limit or avoid it.",
            "Moderate caffeine can help, but excess or late intake can cause anxiety or insomnia in some people.",
            "Added sugars and sweetened drinks cause quick swings in energy.",
          ],
        },
      },
      {
        id: "ch4_when_to_seek_help",
        title: { ar: "متى تطلب المساعدة المختصة", en: "When to Seek Professional Help" },
        pages: {
          ar: [
            "الغذاء يدعم الصحة النفسية، لكنه لا يعالج الاكتئاب أو القلق أو الاضطرابات النفسية.",
            "إذا استمر تغير المزاج أو الحزن أو فقدان الاهتمام أو الإرهاق لأسابيع، فراجع طبيباً أو مختصاً في الصحة النفسية.",
            "إذا راودتك أفكار بإيذاء النفس، فتواصل فوراً مع الطوارئ في بلدك أو خط الدعم النفسي المحلي.",
          ],
          en: [
            "Nutrition supports mental health but does not treat depression, anxiety or other conditions.",
            "If low mood, anxiety, loss of interest or fatigue persist for weeks, see a doctor or mental health professional.",
            "If you have thoughts of harming yourself, contact local emergency services or a local crisis line immediately.",
          ],
        },
      },
    ],
  },
];
