import { useEffect, useState, type FormEvent } from "react";
import { BrowserRouter, Link, Navigate, Route, Routes, useNavigate, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from "firebase/auth";
import { doc, onSnapshot, setDoc } from "firebase/firestore";
import i18n, { resources } from "../i18n";
import { auth, db } from "../features/auth/firebase";
import { GROUPS, EXERCISES, type Prescription } from "../data/exercises";
import { activeLimits, isExcluded } from "../engine/limits";
import { useWorkoutTimer } from "../features/timer/useWorkoutTimer";
import { pick, pickList } from "../ui/i18nPick";
import { BOOKS, type BookChapter } from "../data/books";
import { FlipBook } from "../features/books/FlipBook";
import NUTRITION_FACTS from "../data/facts/nutrition-facts.json";

export type Profile = {
  fullName: string;
  age: number;
  weightKg: number;
  heightCm: number;
  level: "beginner" | "intermediate" | "expert";
  healthLimitations: string[];
  mood: "poor" | "neutral" | "optimal";
};

// ---------- حالة المستخدم ----------
type Session = { user: User | null; profile: Profile | null; loading: boolean };

function useSession(): Session {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubProfile: (() => void) | undefined;
    const unsubAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);
      unsubProfile?.();
      if (!u) {
        setProfile(null);
        setLoading(false);
        return;
      }
      unsubProfile = onSnapshot(doc(db, "users", u.uid, "profile", "main"), (snap) => {
        setProfile(snap.exists() ? (snap.data() as Profile) : null);
        setLoading(false);
      });
    });
    return () => {
      unsubAuth();
      unsubProfile?.();
    };
  }, []);

  return { user, profile, loading };
}

// ---------- التطبيق ----------
export default function App() {
  const session = useSession();

  if (session.loading) return <Splash />;

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={session.user ? <Navigate to="/" replace /> : <LoginScreen />} />
        <Route
          path="/onboarding"
          element={
            !session.user ? <Navigate to="/login" replace /> : session.profile ? <Navigate to="/" replace /> : <OnboardingScreen uid={session.user.uid} />
          }
        />
        <Route
          path="/*"
          element={
            !session.user ? (
              <Navigate to="/login" replace />
            ) : !session.profile ? (
              <Navigate to="/onboarding" replace />
            ) : (
              <Shell session={session} />
            )
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

function Splash() {
  return (
    <div className="splash">
      <div className="glass splash-card">APEX FIT</div>
    </div>
  );
}

// ---------- تسجيل الدخول ----------
function LoginScreen() {
  const { t } = useTranslation();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    try {
      if (mode === "login") await signInWithEmailAndPassword(auth, email, password);
      else await createUserWithEmailAndPassword(auth, email, password);
    } catch {
      setErr(t("auth.error"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-screen">
      <div className="glass auth-card">
        <h1 className="brand">APEX FIT</h1>
        <p className="muted">{t("app.tagline")}</p>
        <form onSubmit={submit} className="stack">
          <input type="email" placeholder={t("auth.email")} value={email} onChange={(e) => setEmail(e.target.value)} required />
          <input type="password" placeholder={t("auth.password")} value={password} onChange={(e) => setPassword(e.target.value)} minLength={6} required />
          {err && <p className="error" role="alert">{err}</p>}
          <button className="primary" type="submit" disabled={busy}>
            {mode === "login" ? t("auth.login") : t("auth.register")}
          </button>
        </form>
        <button className="link" onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? t("auth.register") : t("auth.login")}
        </button>
        <p className="muted small">{t("disclaimer.medical")}</p>
      </div>
      <LangPicker />
    </div>
  );
}

// ---------- الإعداد الأولي ----------
function OnboardingScreen({ uid }: { uid: string }) {
  const { t } = useTranslation();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [level, setLevel] = useState<Profile["level"] | "">("");
  const [limits, setLimits] = useState<string[]>([]);
  const [mood, setMood] = useState<Profile["mood"] | "">("");
  const [err, setErr] = useState(false);
  const titles = ["onboarding.title", "onboarding.level", "onboarding.limitations", "onboarding.mood"];

  function valid(): boolean {
    if (step === 0) {
      const a = +age, w = +weight, h = +height;
      return name.trim().length >= 2 && a >= 13 && a <= 80 && w >= 30 && w <= 250 && h >= 120 && h <= 230;
    }
    if (step === 1) return level !== "";
    if (step === 3) return mood !== "";
    return true;
  }

  async function next() {
    if (!valid()) return setErr(true);
    setErr(false);
    if (step < 3) return setStep(step + 1);
    const profile: Profile = {
      fullName: name.trim(),
      age: +age,
      weightKg: +weight,
      heightCm: +height,
      level: level as Profile["level"],
      healthLimitations: limits.length ? limits : ["none"],
      mood: mood as Profile["mood"],
    };
    await setDoc(doc(db, "users", uid, "profile", "main"), { ...profile, updatedAt: Date.now() }, { merge: true });
  }

  return (
    <div className="auth-screen">
      <div className="glass wizard">
        <progress value={step + 1} max={4} />
        <h2>{t(titles[step])}</h2>

        {step === 0 && (
          <div className="stack">
            <input placeholder={t("onboarding.name")} value={name} onChange={(e) => setName(e.target.value)} />
            <input type="number" inputMode="numeric" placeholder={t("onboarding.age")} value={age} onChange={(e) => setAge(e.target.value)} />
            <input type="number" inputMode="decimal" placeholder={t("onboarding.weight")} value={weight} onChange={(e) => setWeight(e.target.value)} />
            <input type="number" inputMode="numeric" placeholder={t("onboarding.height")} value={height} onChange={(e) => setHeight(e.target.value)} />
          </div>
        )}

        {step === 1 && (
          <div className="options">
            {(["beginner", "intermediate", "expert"] as const).map((l) => (
              <button key={l} className={level === l ? "on" : ""} onClick={() => setLevel(l)}>
                {t(`levels.${l}`)}
              </button>
            ))}
          </div>
        )}

        {step === 2 && (
          <div className="options">
            {["knee", "shoulder", "lower_back", "wrist", "none"].map((l) => {
              const on = limits.includes(l);
              return (
                <button
                  key={l}
                  className={on ? "on" : ""}
                  onClick={() => setLimits(on ? limits.filter((x) => x !== l) : [...limits, l])}
                >
                  {t(`limits.${l}`)}
                </button>
              );
            })}
          </div>
        )}

        {step === 3 && (
          <div className="options">
            {(["poor", "neutral", "optimal"] as const).map((m) => (
              <button key={m} className={mood === m ? "on" : ""} onClick={() => setMood(m)}>
                {t(`mood.${m}`)}
              </button>
            ))}
          </div>
        )}

        {err && <p className="error" role="alert">{t("onboarding.required")}</p>}
        <button className="primary" onClick={next}>
          {step === 3 ? t("onboarding.start") : t("onboarding.next")}
        </button>
      </div>
    </div>
  );
}

// ---------- الهيكل والتنقل ----------
function Shell({ session }: { session: Session }) {
  const { t } = useTranslation();
  const tabs = [
    { to: "/", key: "nav.workouts" },
    { to: "/nutrition", key: "nav.nutrition" },
    { to: "/coach", key: "nav.coach" },
    { to: "/store", key: "nav.store" },
    { to: "/profile", key: "nav.profile" },
  ];

  return (
    <>
      <main className="shell">
        <Routes>
          <Route path="/" element={<WorkoutsScreen profile={session.profile!} />} />
          <Route path="/workouts/:id" element={<ExerciseScreen profile={session.profile!} />} />
          <Route path="/nutrition" element={<NutritionScreen />} />
          <Route path="/coach" element={<CoachScreen profile={session.profile!} />} />
          <Route path="/store" element={<StoreScreen />} />
          <Route path="/profile" element={<ProfileScreen session={session} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <nav className="bottom-nav glass" aria-label="Main">
        {tabs.map((tab) => (
          <Link key={tab.to} to={tab.to} className="tab">
            <span>{t(tab.key)}</span>
          </Link>
        ))}
      </nav>
    </>
  );
}

// ---------- التمارين ----------
function WorkoutsScreen({ profile }: { profile: Profile }) {
  const { t } = useTranslation();
  const limits = activeLimits(profile.healthLimitations);

  return (
    <div className="screen">
      <h1>{t("workouts.title")}</h1>
      {GROUPS.map((g) => (
        <section key={g.key}>
          <h2>{t(`groups.${g.key}`)}</h2>
          <div className="grid">
            {g.items.map((ex) => {
              const adjusted = isExcluded(ex.id, limits);
              return (
                <Link key={ex.id} to={`/workouts/${ex.id}`} className={`glass ex-card ${adjusted ? "dim" : ""}`}>
                  <strong>{pick(ex.name)}</strong>
                  <span className="muted small">
                    {ex.muscles.map((m) => t(`muscles.${m}`, { defaultValue: m })).join(" · ")}
                  </span>
                  <span className="badge">{t(`equipment.${ex.equipment}`)}</span>
                  {adjusted && <em className="warn-text">{t("workouts.adjusted")}</em>}
                </Link>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}

function ExerciseScreen({ profile }: { profile: Profile }) {
  const { id } = useParams();
  const { t } = useTranslation();
  const ex = EXERCISES.find((e) => e.id === id);
  if (!ex) return <div className="screen">{t("workouts.notFound")}</div>;

  const rx = ex.levels[profile.level];
  const adjusted = isExcluded(ex.id, activeLimits(profile.healthLimitations));

  return (
    <div className="screen">
      <BackLink />
      <VideoPlayer src={ex.video} poster={ex.image} title={pick(ex.name)} />
      <h1>{pick(ex.name)}</h1>
      <div className="chips">
        <span>{t(`equipment.${ex.equipment}`)}</span>
        <span>{t("workouts.sets")}: {rx.sets}</span>
        <span>{t("workouts.reps")}: {rx.reps}</span>
        <span>{t("workouts.rest")}: {rx.restSec}s</span>
      </div>
      {adjusted && <div className="glass warn">{t("workouts.adjustedWarning")}</div>}
      <WorkoutTimer rx={rx} />
      <div className="glass">
        <h3>{t("exercise.steps")}</h3>
        <ol>{pickList(ex.steps).map((s, i) => <li key={i}>{s}</li>)}</ol>
      </div>
      <div className="glass">
        <h3>{t("exercise.tips")}</h3>
        <p>{pick(ex.formTips)}</p>
      </div>
      <p className="muted small">{t("disclaimer.medical")}</p>
    </div>
  );
}

function VideoPlayer({ src, poster, title }: { src: string; poster: string; title: string }) {
  return (
    <div className="glass demo-player">
      <video src={src} poster={poster} aria-label={title} loop muted playsInline controls preload="metadata" />
    </div>
  );
}

function WorkoutTimer({ rx }: { rx: Prescription }) {
  const { t } = useTranslation();
  const tm = useWorkoutTimer(rx.workSec, rx.restSec, rx.sets);
  const label = tm.phase === "work" ? t("workouts.work") : tm.phase === "rest" ? t("workouts.rest") : t("timer.done");
  const mm = Math.floor(tm.remaining / 60);
  const ss = String(tm.remaining % 60).padStart(2, "0");

  return (
    <div className="glass timer">
      <div className="muted">{label} · {tm.set}/{rx.sets}</div>
      <div className="timer-clock" aria-live="polite">{mm}:{ss}</div>
      <div className="timer-actions">
        {tm.running ? (
          <button onClick={tm.pause}>{t("timer.pause")}</button>
        ) : (
          <button className="primary" onClick={tm.start} disabled={tm.phase === "done"}>{t("timer.start")}</button>
        )}
        <button onClick={tm.reset}>{t("timer.reset")}</button>
      </div>
    </div>
  );
}

function BackLink() {
  const nav = useNavigate();
  return <button className="link" onClick={() => nav(-1)}>←</button>;
}

// ---------- التغذية ----------
type Recipe = {
  id: string;
  title: { ar: string; en: string };
  category?: string;
  macros: { kcal: number; proteinG: number; carbsG: number; fatG: number };
  ingredients: { ar: string; en: string }[];
  steps: { ar: string[]; en: string[] };
};

function NutritionScreen() {
  const { t } = useTranslation();
  const [tab, setTab] = useState<"recipes" | "facts" | "books">("recipes");
  const [recipes, setRecipes] = useState<Recipe[]>([]);

  useEffect(() => {
    import("../data/recipes").then((m) => setRecipes(m.ALL_RECIPES));
  }, []);

  return (
    <div className="screen">
      <h1>{t("nutrition.title")}</h1>
      <div className="segmented">
        <button className={tab === "recipes" ? "on" : ""} onClick={() => setTab("recipes")}>{t("nutrition.recipes")}</button>
        <button className={tab === "facts" ? "on" : ""} onClick={() => setTab("facts")}>{t("nutrition.facts")}</button>
        <button className={tab === "books" ? "on" : ""} onClick={() => setTab("books")}>{t("nutrition.books")}</button>
      </div>
      {tab === "recipes" && (
        <div className="stack">
          {recipes.map((r) => (
            <RecipeCard key={r.id} r={r} />
          ))}
        </div>
      )}
      {tab === "facts" && <FactsList />}
      {tab === "books" && <BooksList />}
    </div>
  );
}

function BooksList() {
  const { t } = useTranslation();
  const [chapter, setChapter] = useState<BookChapter | null>(null);

  if (chapter) {
    return (
      <>
        <button className="link" onClick={() => setChapter(null)}>{t("nutrition.back")}</button>
        <h2>{pick(chapter.title)}</h2>
        <FlipBook chapter={chapter} />
      </>
    );
  }

  return (
    <div className="stack">
      {BOOKS.map((b) => (
        <section key={b.id}>
          <h2>{pick(b.title)}</h2>
          <div className="grid">
            {b.chapters.map((c) => (
              <button key={c.id} className="glass ex-card" onClick={() => setChapter(c)}>
                <strong>{pick(c.title)}</strong>
              </button>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}

function RecipeCard({ r }: { r: Recipe }) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  return (
    <div className="glass recipe">
      <button className="link title-btn" onClick={() => setOpen(!open)} aria-expanded={open}>{pick(r.title)}</button>
      <div className="chips">
        <span>{r.macros.kcal} {t("nutrition.kcal")}</span>
        <span>P {r.macros.proteinG}g</span>
        <span>C {r.macros.carbsG}g</span>
        <span>F {r.macros.fatG}g</span>
      </div>
      {open && (
        <>
          <h4>{t("nutrition.ingredients")}</h4>
          <ul>{r.ingredients.map((i, idx) => <li key={idx}>{pick(i)}</li>)}</ul>
          <h4>{t("nutrition.steps")}</h4>
          <ol>{pickList(r.steps).map((s, idx) => <li key={idx}>{s}</li>)}</ol>
        </>
      )}
    </div>
  );
}

type Fact = { id: string; phase: "pre" | "during" | "post" | "general"; text: { ar: string; en: string }; source: string };

function FactsList() {
  const { t } = useTranslation();
  const [phase, setPhase] = useState<Fact["phase"]>("pre");
  const [facts, setFacts] = useState<Fact[]>([]);

  useEffect(() => {
    import("../data/facts/athlete-timing.json").then((m) => setFacts(m.default as Fact[]));
  }, []);

  return (
    <>
      <div className="segmented">
        {(["pre", "during", "post", "general"] as const).map((p) => (
          <button key={p} className={phase === p ? "on" : ""} onClick={() => setPhase(p)}>{t(`phase.${p}`)}</button>
        ))}
      </div>
      <div className="stack">
        {facts.filter((f) => f.phase === phase).map((f) => (
          <div key={f.id} className="glass">
            <p>{pick(f.text)}</p>
            <small className="muted">{f.source}</small>
          </div>
        ))}
      </div>
      <h2>{t("nutrition.generalFacts")}</h2>
      <div className="stack">
        {NUTRITION_FACTS.filter((f) => f.published).map((f) => (
          <div key={f.id} className="glass">
            <p>{lang() === "ar" ? f.ar : f.en}</p>
            <small className="muted">{f.source}</small>
          </div>
        ))}
      </div>
    </>
  );
}

const lang = () => (i18n.language.startsWith("ar") ? "ar" : "en");

// ---------- المدرب الذكي ----------
type Msg = { role: "user" | "assistant"; content: string };

function CoachScreen({ profile }: { profile: Profile }) {
  const { t } = useTranslation();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);

  async function send(text: string) {
    if (!text.trim() || busy) return;
    const next: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setBusy(true);
    try {
      const { httpsCallable } = await import("firebase/functions");
      const { functions } = await import("../features/auth/firebase");
      const callCoach = httpsCallable(functions, "coachChat");
      const res = await callCoach({ messages: next, profile });
      setMessages([...next, { role: "assistant", content: (res.data as { reply: string }).reply }]);
    } catch {
      setMessages([...next, { role: "assistant", content: t("coach.error") }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="screen">
      <h1>{t("coach.title")}</h1>
      <div className="glass coach">
        <div className="chat-log">
          {messages.map((m, i) => <div key={i} className={`bubble ${m.role}`}>{m.content}</div>)}
          {busy && <div className="typing">{t("coach.typing")}…</div>}
        </div>
        <form onSubmit={(e) => { e.preventDefault(); void send(input); }}>
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={t("coach.placeholder")} />
          <button type="submit" disabled={busy}>{t("coach.send")}</button>
        </form>
      </div>
      <p className="muted small">{t("disclaimer.medical")}</p>
    </div>
  );
}

// ---------- المتجر ----------
const PRODUCTS = [
  { id: "band_set", name: { ar: "مجموعة أحبال مقاومة", en: "Resistance Band Set" }, url: "", exercises: ["pull_band_curl", "pull_reverse_fly"] },
  { id: "door_bar", name: { ar: "عقلة باب", en: "Doorway Pull-Up Bar" }, url: "", exercises: ["pull_doorway_pullup"] },
  { id: "exercise_mat", name: { ar: "حصيرة تمرين", en: "Exercise Mat" }, url: "", exercises: ["core_crunch", "core_forearm_plank", "legs_glute_bridge"] },
];

function StoreScreen() {
  const { t } = useTranslation();
  return (
    <div className="screen">
      <h1>{t("store.title")}</h1>
      <p className="muted small">{t("store.disclosure")}</p>
      <div className="stack">
        {PRODUCTS.map((p) => (
          <div key={p.id} className="glass product-card">
            <h3>{pick(p.name)}</h3>
            <div className="chips">
              {p.exercises.map((exId) => {
                const ex = EXERCISES.find((e) => e.id === exId);
                return ex ? <Link key={exId} to={`/workouts/${exId}`} className="badge">{pick(ex.name)}</Link> : null;
              })}
            </div>
            <button disabled={!p.url} onClick={() => window.open(p.url, "_blank", "noopener,noreferrer")}>
              {p.url ? t("store.view") : t("store.unavailable")}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- الملف الشخصي واللغة ----------
function ProfileScreen({ session }: { session: Session }) {
  const { t } = useTranslation();
  return (
    <div className="screen">
      <h1>{t("nav.profile")}</h1>
      <div className="glass stack">
        <strong>{session.profile?.fullName}</strong>
        <span className="muted small">{session.user?.email}</span>
        {session.profile && <span className="badge">{t(`levels.${session.profile.level}`)}</span>}
      </div>
      <div className="glass">
        <LangPicker />
      </div>
      <button className="primary" onClick={() => signOut(auth)}>{t("auth.logout")}</button>
      <p className="muted small">{t("disclaimer.mood")}</p>
    </div>
  );
}

function LangPicker() {
  const langs = Object.keys(resources);
  const nameOf = (code: string) => new Intl.DisplayNames([code], { type: "language" }).of(code) ?? code;
  return (
    <label className="stack">
      <span>{i18n.t("profile.language")}</span>
      <select
        value={i18n.language}
        onChange={(e) => {
          void i18n.changeLanguage(e.target.value);
          localStorage.setItem("apex.lang", e.target.value);
        }}
      >
        {langs.map((code) => <option key={code} value={code}>{nameOf(code)}</option>)}
      </select>
    </label>
  );
}
