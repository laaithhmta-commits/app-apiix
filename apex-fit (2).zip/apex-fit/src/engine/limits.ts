// قائمة مبدئية تحتاج مراجعة مختصة قبل النشر.
export const LIMIT_EXCLUDES: Record<string, string[]> = {
  knee: ["legs_walking_lunge"],
  shoulder: ["push_pike", "push_decline_chair"],
  wrist: ["push_diamond"],
  lower_back: ["core_bicycle_crunch"],
};

export function activeLimits(limits: string[] | undefined): string[] {
  return (limits ?? []).filter((l) => l !== "none");
}

export function isExcluded(exerciseId: string, limits: string[]): boolean {
  return limits.some((l) => LIMIT_EXCLUDES[l]?.includes(exerciseId));
}
