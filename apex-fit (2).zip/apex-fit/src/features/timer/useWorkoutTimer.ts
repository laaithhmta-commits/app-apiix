import { useCallback, useEffect, useRef, useState } from "react";

type Phase = "work" | "rest" | "done";

export function useWorkoutTimer(workSec: number, restSec: number, totalSets: number) {
  const [set, setSet] = useState(1);
  const [phase, setPhase] = useState<Phase>("work");
  const [remaining, setRemaining] = useState(workSec);
  const [running, setRunning] = useState(false);
  const audioCtx = useRef<AudioContext | null>(null);

  const beep = useCallback((freq = 880, ms = 150) => {
    try {
      if (!audioCtx.current) audioCtx.current = new AudioContext();
      const ctx = audioCtx.current;
      if (ctx.state === "suspended") void ctx.resume();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq;
      gain.gain.value = 0.2;
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + ms / 1000);
    } catch {
      // الصوت غير متاح في هذه البيئة، والمؤقت يعمل بصرياً
    }
  }, []);

  // العد التنازلي كل ثانية
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setRemaining((r) => Math.max(0, r - 1)), 1000);
    return () => clearInterval(id);
  }, [running]);

  // التنبيهات والانتقالات بين العمل والراحة
  useEffect(() => {
    if (!running) return;
    if (remaining > 0 && remaining <= 3) beep(1000, 80);
    if (remaining > 0) return;

    if (phase === "work") {
      beep(660, 300);
      if (set >= totalSets) {
        setPhase("done");
        setRunning(false);
        beep(1200, 600);
        return;
      }
      setPhase("rest");
      setRemaining(restSec);
    } else if (phase === "rest") {
      beep(880, 200);
      setSet((s) => s + 1);
      setPhase("work");
      setRemaining(workSec);
    }
  }, [remaining, running, phase, set, totalSets, workSec, restSec, beep]);

  return {
    set,
    phase,
    remaining,
    running,
    start: () => setRunning(true),
    pause: () => setRunning(false),
    reset: () => {
      setSet(1);
      setPhase("work");
      setRemaining(workSec);
      setRunning(false);
    },
  };
}
