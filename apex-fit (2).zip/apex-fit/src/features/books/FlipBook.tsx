import { useState } from "react";
import type { BookChapter } from "../../data/books";
import { currentLang } from "../../ui/i18nPick";

// قلب الصفحات بحركة ثلاثية الأبعاد
export function FlipBook({ chapter }: { chapter: BookChapter }) {
  const lang = currentLang();
  const pages = chapter.pages[lang];
  const [index, setIndex] = useState(0);
  const [turning, setTurning] = useState<"next" | "prev" | null>(null);

  function go(dir: "next" | "prev") {
    const target = dir === "next" ? index + 1 : index - 1;
    if (target < 0 || target >= pages.length || turning) return;
    setTurning(dir);
    setTimeout(() => {
      setIndex(target);
      setTurning(null);
    }, 450);
  }

  const angle = turning === "next" ? "-90deg" : turning === "prev" ? "90deg" : "0deg";

  return (
    <div className="flipbook" style={{ perspective: 1400 }}>
      <div
        className="page"
        style={{
          transform: `rotateY(${angle})`,
          transition: "transform 450ms cubic-bezier(.22,.61,.36,1)",
          transformOrigin: lang === "ar" ? "right center" : "left center",
        }}
      >
        <p>{pages[index]}</p>
      </div>
      <div className="controls">
        <button onClick={() => go("prev")} disabled={index === 0}>{lang === "ar" ? "السابق" : "Previous"}</button>
        <span>{index + 1} / {pages.length}</span>
        <button onClick={() => go("next")} disabled={index === pages.length - 1}>{lang === "ar" ? "التالي" : "Next"}</button>
      </div>
    </div>
  );
}
