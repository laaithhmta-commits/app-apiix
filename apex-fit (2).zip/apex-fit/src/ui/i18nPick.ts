import i18n from "../i18n";

type Loc = { ar?: string; en?: string };
type LocList = { ar: string[]; en: string[] };

export function currentLang(): "ar" | "en" {
  return i18n.language.startsWith("ar") ? "ar" : "en";
}

export function pick(v: Loc | undefined): string {
  if (!v) return "";
  const l = currentLang();
  return v[l] ?? v.en ?? v.ar ?? "";
}

export function pickList(v: LocList): string[] {
  return v[currentLang()] ?? v.en;
}
