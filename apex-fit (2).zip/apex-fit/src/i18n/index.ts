import i18n from "i18next";
import { initReactI18next } from "react-i18next";

const modules = import.meta.glob("./locales/*.json", { eager: true }) as Record<
  string,
  { default: Record<string, unknown> }
>;

export const resources: Record<string, { translation: Record<string, unknown> }> = {};
for (const path in modules) {
  const code = path.replace("./locales/", "").replace(".json", "");
  // الحظر الصارم للعبرية
  if (code === "he" || code === "iw") continue;
  resources[code] = { translation: modules[path].default };
}

export const RTL_LOCALES = ["ar", "fa", "ur"];
export const isRtl = (lng: string) => RTL_LOCALES.includes(lng.split("-")[0]);

export function applyDirection(lng: string) {
  document.documentElement.lang = lng;
  document.documentElement.dir = isRtl(lng) ? "rtl" : "ltr";
}

const saved = localStorage.getItem("apex.lang");

i18n.use(initReactI18next).init({
  resources,
  lng: saved && resources[saved] ? saved : "ar",
  fallbackLng: "en",
  interpolation: { escapeValue: false },
});

i18n.on("languageChanged", applyDirection);
applyDirection(i18n.language);

export default i18n;
